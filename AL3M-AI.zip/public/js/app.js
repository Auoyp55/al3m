'use strict';

const $ = (id) => document.getElementById(id);

const state = {
  tool: 'chat',
  chats: [],
  activeChat: null,
  attachedText: ''
};

const tools = {
  chat: {
    title: 'مركز الذكاء',
    placeholder: 'اكتب فكرتك هنا...',
    hint: 'اكتب سؤالك أو الفكرة التي تريد العمل عليها.'
  },
  code: {
    title: 'مختبر البرمجة',
    placeholder: 'اشرح الكود أو المشروع الذي تريد تطويره...',
    hint: 'اكتب لغة البرمجة والمطلوب، أو الصق الكود الذي تريد مراجعته.'
  },
  writer: {
    title: 'استوديو الكتابة',
    placeholder: 'ما المحتوى الذي تريد كتابته؟',
    hint: 'حدد نوع المحتوى والجمهور والنبرة المطلوبة.'
  },
  translate: {
    title: 'الترجمة الذكية',
    placeholder: 'الصق النص الذي تريد ترجمته...',
    hint: 'أرسل النص وحدد اللغة الأصلية واللغة المستهدفة.'
  },
  ideas: {
    title: 'مختبر الأفكار',
    placeholder: 'ما الفكرة التي تريد تطويرها؟',
    hint: 'اكتب فكرتك وحدد المجال أو الهدف الذي تسعى إليه.'
  },
  summarize: {
    title: 'تلخيص النصوص',
    placeholder: 'الصق النص الذي تريد تلخيصه...',
    hint: 'الصق النص وحدد إن كنت تريد ملخصًا قصيرًا أو مفصلًا.'
  }
};

function toast(message) {
  const box = $('toast');
  if (!box) return;

  box.textContent = message;
  box.classList.add('show');

  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => box.classList.remove('show'), 2800);
}

function loadChats() {
  try {
    const saved = JSON.parse(localStorage.getItem('al3m_ai_chats') || '[]');
    state.chats = Array.isArray(saved) ? saved : [];
  } catch {
    state.chats = [];
  }

  renderHistory();
}

function saveChats() {
  try {
    localStorage.setItem('al3m_ai_chats', JSON.stringify(state.chats));
  } catch {
    toast('تعذر الحفظ المحلي. قد تكون مساحة التخزين ممتلئة.');
  }
}

function renderHistory() {
  const list = $('historyList');
  if (!list) return;

  list.replaceChildren();

  if (!state.chats.length) {
    const empty = document.createElement('div');
    empty.className = 'history-empty';
    empty.textContent = 'لا توجد محادثات محفوظة';
    list.appendChild(empty);
    return;
  }

  state.chats.slice().reverse().slice(0, 30).forEach(chat => {
    const button = document.createElement('button');
    button.className = 'history-item';
    button.textContent = chat.title || 'محادثة جديدة';
    button.title = chat.title || '';
    button.addEventListener('click', () => openChat(chat.id));
    list.appendChild(button);
  });
}

function getCurrentChat() {
  return state.chats.find(chat => chat.id === state.activeChat) || null;
}

function createChat() {
  const chat = {
    id: Date.now().toString(36) + Math.random().toString(36).slice(2, 7),
    title: 'محادثة جديدة',
    tool: state.tool,
    messages: [],
    updatedAt: Date.now()
  };

  state.chats.push(chat);
  state.activeChat = chat.id;
  saveChats();
  renderHistory();
  renderMessages();
  return chat;
}

function openChat(id) {
  const chat = state.chats.find(item => item.id === id);
  if (!chat) return;

  state.activeChat = id;
  state.tool = chat.tool || 'chat';
  selectToolButtons();
  updateToolUI();
  renderMessages();
  closeSidebar();
}

function newChat() {
  state.activeChat = null;
  state.attachedText = '';

  $('promptInput').value = '';
  $('welcomeView').classList.remove('hidden');
  $('chatView').classList.add('hidden');

  updateToolUI();
  closeSidebar();
  $('promptInput').focus();
}

function selectToolButtons() {
  document.querySelectorAll('[data-tool]').forEach(button => {
    if (button.classList.contains('nav-item')) {
      button.classList.toggle('active', button.dataset.tool === state.tool);
    }
  });
}

function updateToolUI() {
  const tool = tools[state.tool] || tools.chat;

  $('pageTitle').textContent = tool.title;
  $('contextLabel').textContent = tool.title;
  $('promptInput').placeholder = tool.placeholder;

  selectToolButtons();
}

function chooseTool(name) {
  if (!tools[name]) return;

  state.tool = name;
  state.activeChat = null;

  updateToolUI();
  $('promptInput').focus();
  closeSidebar();

  if (name !== 'chat') {
    toast('تم فتح ' + tools[name].title);
  }
}

function addMessage(role, text) {
  const messages = $('chatMessages');
  const article = document.createElement('article');
  article.className = 'message ' + role;

  const avatar = document.createElement('div');
  avatar.className = 'message-avatar';
  avatar.textContent = role === 'user' ? 'أنت' : 'A';

  const content = document.createElement('div');
  content.className = 'message-content';

  const name = document.createElement('div');
  name.className = 'message-name';
  name.textContent = role === 'user' ? 'أنت' : 'AL3M AI';

  const body = document.createElement('div');
  body.className = 'message-text';
  body.textContent = text;

  content.append(name, body);
  article.append(avatar, content);
  messages.appendChild(article);

  return article;
}

function renderMessages() {
  const chat = getCurrentChat();
  const messages = $('chatMessages');

  messages.replaceChildren();

  if (chat && chat.messages.length) {
    $('welcomeView').classList.add('hidden');
    $('chatView').classList.remove('hidden');

    chat.messages.forEach(message => {
      addMessage(message.role, message.text);
    });
  } else {
    $('welcomeView').classList.remove('hidden');
    $('chatView').classList.add('hidden');
  }

  messages.scrollTop = messages.scrollHeight;
}

async function sendMessage() {
  const input = $('promptInput');
  const text = input.value.trim();

  if (!text && !state.attachedText) {
    toast('اكتب رسالتك أولاً');
    input.focus();
    return;
  }

  const finalText = state.attachedText
    ? text + (text ? '\n\n' : '') + '[محتوى الملف]\n' + state.attachedText
    : text;

  let chat = getCurrentChat();

  if (!chat) {
    chat = createChat();
    chat.tool = state.tool;
  }

  if (!chat.messages.length) {
    chat.title = finalText.replace(/\s+/g, ' ').slice(0, 45) || 'محادثة جديدة';
    chat.tool = state.tool;
  }

  chat.messages.push({
    role: 'user',
    text: finalText,
    time: Date.now()
  });

  chat.updatedAt = Date.now();
  state.attachedText = '';
  input.value = '';
  resizeInput();

  saveChats();
  renderHistory();
  renderMessages();

  const sendButton = $('sendButton');
  sendButton.disabled = true;
  sendButton.textContent = '…';

  const waiting = addMessage('assistant', 'AL3M AI يفكر الآن…');

  try {
    const response = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        message: finalText,
        tool: chat.tool || state.tool,
        history: chat.messages.slice(0, -1).map(item => ({
          role: item.role,
          text: item.text
        }))
      })
    });

    const data = await response.json().catch(() => ({}));

    if (!response.ok) {
      throw new Error(data.error || 'حدث خطأ أثناء الاتصال بمحرك الذكاء الاصطناعي.');
    }

    const answer = String(data.answer || '').trim();

    if (!answer) {
      throw new Error('وصل رد فارغ من المحرك.');
    }

    waiting.querySelector('.message-text').textContent = answer;

    chat.messages.push({
      role: 'assistant',
      text: answer,
      time: Date.now()
    });
  } catch (error) {
    const message = error.message === 'Failed to fetch'
      ? 'تعذر الاتصال بالخادم. تأكد أن Termux والخادم ما زالا يعملان.'
      : error.message;

    waiting.querySelector('.message-text').textContent =
      'تعذر إكمال الطلب: ' + message;

    chat.messages.push({
      role: 'assistant',
      text: 'تعذر إكمال الطلب: ' + message,
      time: Date.now()
    });
  } finally {
    chat.updatedAt = Date.now();
    saveChats();
    renderHistory();
    sendButton.disabled = false;
    sendButton.textContent = '↑';
    $('chatMessages').scrollTop = $('chatMessages').scrollHeight;
  }
}

function resizeInput() {
  const input = $('promptInput');
  input.style.height = 'auto';
  input.style.height = Math.min(input.scrollHeight, 180) + 'px';
}

function openSidebar() {
  document.body.classList.add('sidebar-open');
}

function closeSidebar() {
  document.body.classList.remove('sidebar-open');
}

function toggleTheme() {
  const light = document.body.classList.toggle('light');

  try {
    localStorage.setItem('al3m_ai_theme', light ? 'light' : 'dark');
  } catch {}

  toast(light ? 'تم تفعيل المظهر الفاتح' : 'تم تفعيل المظهر الداكن');
}

function loadTheme() {
  try {
    if (localStorage.getItem('al3m_ai_theme') === 'light') {
      document.body.classList.add('light');
    }
  } catch {}
}

function openSettings() {
  $('settingsModal').classList.remove('hidden');
}

function closeSettings() {
  $('settingsModal').classList.add('hidden');
}

function attachFile() {
  $('fileInput').click();
}

async function readFile(file) {
  if (!file) return;

  const maxSize = 1024 * 1024;

  if (file.size > maxSize) {
    toast('حجم الملف أكبر من 1 ميغابايت');
    return;
  }

  const textExtensions = /\.(txt|md|json|js|ts|html|css|kt|java|py|xml|csv|log|yaml|yml)$/i;

  if (!textExtensions.test(file.name)) {
    toast('هذا الإصدار يدعم قراءة الملفات النصية فقط');
    return;
  }

  try {
    state.attachedText = await file.text();
    $('promptInput').value =
      ($('promptInput').value.trim() + '\\n' + 'راجع الملف المرفق: ' + file.name).trim();

    resizeInput();
    toast('تم إرفاق محتوى الملف محليًا');
  } catch {
    toast('تعذر قراءة الملف');
  }

  $('fileInput').value = '';
}

function clearChats() {
  if (!state.chats.length) {
    toast('لا توجد محادثات لمسحها');
    return;
  }

  const confirmed = window.confirm('هل تريد حذف جميع المحادثات المحفوظة من هذا المتصفح؟');
  if (!confirmed) return;

  state.chats = [];
  state.activeChat = null;

  saveChats();
  renderHistory();
  renderMessages();
  newChat();

  toast('تم مسح سجل المحادثات');
}

function promptHelp() {
  const examples = {
    chat: 'اشرح لي فكرة جديدة يمكنني تنفيذها خطوة بخطوة.',
    code: 'أريد تطوير مشروع برمجي. ساعدني في تحديد الملفات والخطوات المطلوبة.',
    writer: 'اكتب إعلانًا احترافيًا قصيرًا بأسلوب قوي وواضح.',
    translate: 'ترجم النص التالي إلى الإنجليزية مع الحفاظ على المعنى:',
    ideas: 'اقترح خمس أفكار مبتكرة لمشروع رقمي يمكن تطويره بتكلفة منخفضة.',
    summarize: 'لخّص النص التالي في نقاط واضحة مع استخراج أهم الأفكار:'
  };

  const input = $('promptInput');
  input.value = examples[state.tool] || examples.chat;
  resizeInput();
  input.focus();
}

function bindEvents() {
  $('newChat').addEventListener('click', newChat);
  $('sendButton').addEventListener('click', sendMessage);

  $('promptInput').addEventListener('input', resizeInput);

  $('promptInput').addEventListener('keydown', event => {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      sendMessage();
    }
  });

  document.querySelectorAll('[data-tool]').forEach(button => {
    button.addEventListener('click', () => chooseTool(button.dataset.tool));
  });

  $('openSidebar').addEventListener('click', openSidebar);
  $('closeSidebar').addEventListener('click', closeSidebar);
  $('mobileOverlay').addEventListener('click', closeSidebar);

  $('themeButton').addEventListener('click', toggleTheme);
  $('modalTheme').addEventListener('click', toggleTheme);

  $('settingsButton').addEventListener('click', openSettings);
  $('settingsTop').addEventListener('click', openSettings);
  $('closeSettings').addEventListener('click', closeSettings);

  $('settingsModal').addEventListener('click', event => {
    if (event.target === $('settingsModal')) closeSettings();
  });

  $('clearChats').addEventListener('click', clearChats);
  $('attachButton').addEventListener('click', attachFile);
  $('fileInput').addEventListener('change', event => {
    readFile(event.target.files && event.target.files[0]);
  });

  $('promptHint').addEventListener('click', promptHelp);

  $('resetContext').addEventListener('click', () => {
    state.attachedText = '';
    $('promptInput').value = '';
    resizeInput();
    toast('تم تنظيف مربع الكتابة');
  });

  document.addEventListener('keydown', event => {
    if (event.key === 'Escape') {
      closeSidebar();
      closeSettings();
    }

    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') {
      event.preventDefault();
      newChat();
    }
  });
}

function init() {
  loadTheme();
  loadChats();
  bindEvents();
  updateToolUI();
  renderMessages();

  console.log('AL3M AI Fusion OS initialized.');
}

document.addEventListener('DOMContentLoaded', init);
