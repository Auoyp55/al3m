'use strict';

const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');

const ROOT = path.resolve(__dirname, 'public');
const PORT = Number(process.env.PORT) || 3000;

function loadEnv() {
  try {
    const content = fs.readFileSync(path.join(__dirname, '.env'), 'utf8');
    for (const line of content.split(/\r?\n/)) {
      const match = line.match(/^\s*([A-Z_]+)\s*=\s*(.*)\s*$/);
      if (match && !process.env[match[1]]) {
        process.env[match[1]] = match[2].replace(/^['"]|['"]$/g, '');
      }
    }
  } catch {}
}

loadEnv();

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.webp': 'image/webp'
};

function json(res, status, data) {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff'
  });
  res.end(JSON.stringify(data));
}

function readBody(req, limit = 100 * 1024) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.setEncoding('utf8');

    req.on('data', chunk => {
      body += chunk;
      if (Buffer.byteLength(body) > limit) {
        reject(new Error('BODY_TOO_LARGE'));
        req.destroy();
      }
    });

    req.on('end', () => {
      try {
        resolve(JSON.parse(body || '{}'));
      } catch {
        reject(new Error('INVALID_JSON'));
      }
    });

    req.on('error', reject);
  });
}

async function handleChat(req, res) {
  if (!process.env.GEMINI_API_KEY) {
    return json(res, 503, {
      error: 'مفتاح Gemini API غير مضبوط في ملف .env.'
    });
  }

  let body;

  try {
    body = await readBody(req);
  } catch (error) {
    return json(res, error.message === 'BODY_TOO_LARGE' ? 413 : 400, {
      error: error.message === 'BODY_TOO_LARGE'
        ? 'حجم الطلب كبير جدًا.'
        : 'تعذر قراءة الرسالة.'
    });
  }

  const message = typeof body.message === 'string'
    ? body.message.trim()
    : '';

  if (!message) {
    return json(res, 400, { error: 'اكتب رسالة أولًا.' });
  }

  if (message.length > 20000) {
    return json(res, 413, { error: 'الرسالة طويلة جدًا.' });
  }

  const allowedTools = [
    'chat', 'code', 'writer', 'translate', 'ideas', 'summarize'
  ];

  const tool = allowedTools.includes(body.tool) ? body.tool : 'chat';

  const instructions = {
    chat: 'أنت AL3M AI، مساعد ذكي ودود. أجب بوضوح وبدقة، واستخدم العربية عندما تناسب المستخدم.',
    code: 'أنت AL3M AI Code Lab. ساعد في البرمجة، واكتب أكوادًا قابلة للاستخدام واشرح الأخطاء والخطوات.',
    writer: 'أنت AL3M AI Writer Studio. اكتب نصوصًا احترافية تناسب طلب المستخدم ولغته ونبرته.',
    translate: 'أنت AL3M AI Translator. ترجم النصوص بدقة وحافظ على المعنى والتنسيق. لا تضف شرحًا غير مطلوب.',
    ideas: 'أنت AL3M AI Idea Lab. اقترح أفكارًا مبتكرة وعملية، واشرح كيفية تنفيذها.',
    summarize: 'أنت AL3M AI Text Analyzer. لخّص النصوص بوضوح، واستخرج الأفكار الرئيسية دون اختلاق معلومات.'
  };

  const history = Array.isArray(body.history) ? body.history : [];

  const contents = history
    .filter(item =>
      item &&
      ['user', 'assistant', 'model'].includes(item.role) &&
      typeof item.text === 'string'
    )
    .slice(-12)
    .map(item => ({
      role: item.role === 'user' ? 'user' : 'model',
      parts: [{ text: item.text.slice(0, 12000) }]
    }));

  if (!contents.length || contents[contents.length - 1].role !== 'user') {
    contents.push({ role: 'user', parts: [{ text: message }] });
  }

  try {
    const model = process.env.GEMINI_MODEL || 'gemini-2.5-flash-lite';

    const response = await fetch(
      'https://generativelanguage.googleapis.com/v1beta/models/' +
      encodeURIComponent(model) + ':generateContent',
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-goog-api-key': process.env.GEMINI_API_KEY
        },
        body: JSON.stringify({
          systemInstruction: {
            parts: [{ text: instructions[tool] }]
          },
          contents,
          generationConfig: {
            temperature: 0.7,
            maxOutputTokens: 2048
          }
        }),
        signal: AbortSignal.timeout(90000)
      }
    );

    const result = await response.json().catch(() => ({}));

    if (!response.ok) {
      console.error('Gemini HTTP status:', response.status);

      const status = response.status === 429 ? 429 : 502;

      return json(res, status, {
        error: response.status === 429
          ? 'تم بلوغ حد الاستخدام أو الطلبات. تحقق من حصة API وحاول لاحقًا.'
          : response.status === 400
            ? 'رفض النموذج الطلب. تحقق من إعداداته أو محتوى الرسالة.'
            : response.status === 403
              ? 'المفتاح غير صالح أو لا يملك صلاحية استخدام الخدمة.'
              : 'تعذر الحصول على رد من Gemini. تحقق من المفتاح والاتصال.'
      });
    }

    const answer = (result.candidates || [])
      .flatMap(candidate => candidate.content?.parts || [])
      .map(part => part.text || '')
      .join('')
      .trim();

    if (!answer) {
      return json(res, 502, {
        error: 'لم يرجع النموذج نصًا. جرّب صياغة السؤال بطريقة أخرى.'
      });
    }

    return json(res, 200, { answer });
  } catch (error) {
    console.error('Gemini request failed:', error.name);

    return json(res, 502, {
      error: error.name === 'TimeoutError'
        ? 'استغرق الرد وقتًا طويلًا. حاول مجددًا.'
        : 'تعذر الاتصال بمحرك الذكاء الاصطناعي. تحقق من الإنترنت.'
    });
  }
}

const server = http.createServer(async (req, res) => {
  const pathname = new URL(req.url, 'http://localhost').pathname;

  if (pathname === '/api/chat') {
    if (req.method !== 'POST') {
      res.setHeader('Allow', 'POST');
      return json(res, 405, { error: 'طريقة الطلب غير مدعومة.' });
    }

    return handleChat(req, res);
  }

  if (req.method !== 'GET' && req.method !== 'HEAD') {
    res.writeHead(405);
    return res.end('Method Not Allowed');
  }

  let decoded;

  try {
    decoded = decodeURIComponent(pathname);
  } catch {
    res.writeHead(400);
    return res.end('Bad Request');
  }

  const requestedPath = decoded === '/' ? '/index.html' : decoded;
  const file = path.resolve(ROOT, '.' + requestedPath);

  if (file !== ROOT && !file.startsWith(ROOT + path.sep)) {
    res.writeHead(403);
    return res.end('Forbidden');
  }

  fs.stat(file, (error, stat) => {
    if (error || !stat.isFile()) {
      res.writeHead(404);
      return res.end('404 - File Not Found');
    }

    res.writeHead(200, {
      'Content-Type': MIME[path.extname(file).toLowerCase()] ||
        'application/octet-stream',
      'Cache-Control': 'no-cache',
      'X-Content-Type-Options': 'nosniff'
    });

    if (req.method === 'HEAD') return res.end();

    fs.createReadStream(file).pipe(res);
  });
});

server.listen(PORT, '127.0.0.1', () => {
  console.log('================================');
  console.log('       AL3M AI FUSION OS');
  console.log('================================');
  console.log('الموقع: http://127.0.0.1:' + PORT);
  console.log('محرك Gemini: ' +
    (process.env.GEMINI_API_KEY ? 'مهيأ' : 'يحتاج مفتاح API'));
  console.log('لإيقاف الخادم: CTRL + C');
});
